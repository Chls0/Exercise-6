# Exercise3 GROUP3 MEMBERS
Geryme Elimino - Leader
Jestine Toribio
Zedrick Prado
Joseph Hansol
ChelSea Ordona
