<footer>
    <p>&copy; <?= date('Y') ?> Meet the Crew. All rights reserved.</p>
</footer>
</body>
</html>
